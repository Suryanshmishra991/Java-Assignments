import java.util.Scanner;

// Custom Exception
class InvalidAgeException extends Exception {
    InvalidAgeException(String message) {
        super(message);
    }
}

public class StudentRegistration {

    public static void checkAge(int age) throws InvalidAgeException {
        if (age <= 18) {
            throw new InvalidAgeException("Age must be 18 or above.");
        }
        System.out.println("Student registered successfully.");
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Age: ");
        int age = sc.nextInt();

        try {
            checkAge(age);
        } catch (InvalidAgeException e) {
            System.out.println(e.getMessage());
        }

        sc.close();
    }
}